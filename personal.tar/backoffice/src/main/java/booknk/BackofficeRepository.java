package booknk;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface BackofficeRepository extends PagingAndSortingRepository<Backoffice, Long>{


}